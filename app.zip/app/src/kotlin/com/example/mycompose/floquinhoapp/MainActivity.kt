package com.example.mycompose.floquinhoapp

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.Pets
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material.icons.rounded.Upload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshots.SnapshotStateMap
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Mantém o layout em tela cheia de ponta a ponta
        WindowCompat.setDecorFitsSystemWindows(window, false)
        
        // Deixa a barra de status e de navegação preta sólida
        window.statusBarColor = android.graphics.Color.BLACK
        window.navigationBarColor = android.graphics.Color.BLACK

        setContent {
            FloquinhoDynamicTheme {
                FloquinhoAppRoot()
            }
        }
    }
}

@Composable
fun FloquinhoDynamicTheme(content: @Composable () -> Unit) {
    val context = LocalContext.current
    val darkTheme = isSystemInDarkTheme()

    val colorScheme = when {
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> darkColorScheme(
            primary = Color(0xFFFFB870),
            background = Color(0xFF1A1410),
            surface = Color(0xFF28201A),
            onSurface = Color(0xFFF3E5D8)
        )
        else -> lightColorScheme(
            primary = Color(0xFF8C4F00),
            background = Color(0xFFFFF8F2),
            surface = Color(0xFFF7ECE1),
            onSurface = Color(0xFF211A14)
        )
    }

    MaterialTheme(colorScheme = colorScheme, content = content)
}

val TRANSLATION_KEYS = listOf(
    "tab_inicio" to "Início",
    "tab_comunidade" to "Comunidade",
    "tab_amizades" to "Amizades",
    "tab_config" to "Config.",
    "hero_title" to "Título Principal",
    "hero_bio" to "Biografia do Floquinho",
    "card_breed_title" to "Título Raça",
    "card_breed_desc" to "Descrição Raça",
    "card_mood_title" to "Título Humor",
    "card_mood_desc" to "Descrição Humor",
    "card_snack_title" to "Título Petisco",
    "card_snack_desc" to "Descrição Petisco",
    "friends_status" to "Status de Amizade",
    "comm_title" to "Traduções da Comunidade",
    "comm_editing" to "Editando",
    "comm_new_lang_btn" to "Criar Novo Idioma",
    "comm_confirm_btn" to "Confirmar e Aplicar Idioma",
    "comm_success" to "Tradução salva com sucesso!",
    "comm_dialog_title" to "Criar Novo Idioma",
    "comm_dialog_label" to "Nome (ex: Español, Doguês)",
    "comm_dialog_create" to "Criar",
    "comm_dialog_cancel" to "Cancelar",
    "friends_header" to "Adicionar Aumigo via GitHub",
    "friends_name_label" to "Nome do Desenvolvedor (Opcional)",
    "friends_link_label" to "Link ou usuário do GitHub",
    "friends_add_btn" to "Identificar e Adicionar Aumigo",
    "config_header" to "Configurações e Storage",
    "config_snack_alert" to "Alertas de Petisco",
    "config_snack_desc" to "Lembrar de dar biscoitinho ao Floquinho",
    "config_storage_title" to "Gerenciador de Storage (Traduções)",
    "config_export_btn" to "Exportar",
    "config_import_btn" to "Importar",
    "config_active_lang" to "Idioma Ativo no App",
    "affection_info" to "Carinho"
)

data class AmigoDev(
    val nome: String,
    val githubUser: String,
    val avatarUrl: String,
    val favorito: Boolean
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FloquinhoAppRoot() {
    val context = LocalContext.current
    val sharedPrefs = remember { context.getSharedPreferences("FloquinhoPrefs", Context.MODE_PRIVATE) }

    val translations = remember {
        val savedTranslations = sharedPrefs.getString("traducoes_storage_json", null)
        if (savedTranslations != null) {
            try {
                val json = JSONObject(savedTranslations)
                val map = mutableStateMapOf<String, SnapshotStateMap<String, String>>()
                val keys = json.keys()
                while (keys.hasNext()) {
                    val lang = keys.next() as String
                    val subJson = json.getJSONObject(lang)
                    val subMap = mutableStateMapOf<String, String>()
                    val subKeys = subJson.keys()
                    while (subKeys.hasNext()) {
                        val k = subKeys.next() as String
                        subMap[k] = subJson.getString(k)
                    }
                    map[lang] = subMap
                }
                map
            } catch (e: Exception) {
                mutableStateMapOf()
            }
        } else {
            mutableStateMapOf(
                "Português (BR)" to mutableStateMapOf(
                    "tab_inicio" to "Início",
                    "tab_comunidade" to "Comunidade",
                    "tab_amizades" to "Amizades",
                    "tab_config" to "Config.",
                    "hero_title" to "Oi, eu sou o Floquinho!",
                    "hero_bio" to "Spitz Alemão caramelo e creme, especialista em sorrir pra câmera e pedir carinho.",
                    "card_breed_title" to "Pelagem & Porte",
                    "card_breed_desc" to "Bola de pelos fofinha com orelhinhas atentas e sorriso oficial da casa.",
                    "card_mood_title" to "Humor Atual",
                    "card_mood_desc" to "100% feliz, pronto pra brincar na sala ou ganhar petisco.",
                    "card_snack_title" to "Petisco Favorito",
                    "card_snack_desc" to "Biscoitinho natural de frango e pedacinhos de maçã.",
                    "friends_status" to "Aumigos Desenvolvedores",
                    "comm_title" to "Traduções da Comunidade",
                    "comm_editing" to "Editando",
                    "comm_new_lang_btn" to "Criar Novo Idioma",
                    "comm_confirm_btn" to "Confirmar e Aplicar Idioma",
                    "comm_success" to "Tradução salva com sucesso!",
                    "comm_dialog_title" to "Criar Novo Idioma",
                    "comm_dialog_label" to "Nome (ex: Español, Doguês)",
                    "comm_dialog_create" to "Criar",
                    "comm_dialog_cancel" to "Cancelar",
                    "friends_header" to "Adicionar Aumigo via GitHub",
                    "friends_name_label" to "Nome do Desenvolvedor (Opcional)",
                    "friends_link_label" to "Link ou usuário do GitHub",
                    "friends_add_btn" to "Identificar e Adicionar Aumigo",
                    "config_header" to "Configurações e Storage",
                    "config_snack_alert" to "Alertas de Petisco",
                    "config_snack_desc" to "Lembrar de dar biscoitinho ao Floquinho",
                    "config_storage_title" to "Gerenciador de Storage (Traduções)",
                    "config_export_btn" to "Exportar",
                    "config_import_btn" to "Importar",
                    "config_active_lang" to "Idioma Ativo no App",
                    "affection_info" to "Carinho"
                ),
                "English" to mutableStateMapOf(
                    "tab_inicio" to "Home",
                    "tab_comunidade" to "Community",
                    "tab_amizades" to "Friends",
                    "tab_config" to "Config.",
                    "hero_title" to "Hi, I'm Floquinho!",
                    "hero_bio" to "Cream & caramel Pomeranian, expert at smiling for photos and asking for belly rubs.",
                    "card_breed_title" to "Coat & Size",
                    "card_breed_desc" to "Fluffy cloud with perky ears and the happiest smile in town.",
                    "card_mood_title" to "Current Mood",
                    "card_mood_desc" to "100% joyful, ready to play in the living room or get treats.",
                    "card_snack_title" to "Favorite Treat",
                    "card_snack_desc" to "Crunchy chicken biscuits and tiny apple slices.",
                    "friends_status" to "Developer pup friends",
                    "comm_title" to "Community Translations",
                    "comm_editing" to "Editing",
                    "comm_new_lang_btn" to "Create New Language",
                    "comm_confirm_btn" to "Confirm and Apply Language",
                    "comm_success" to "Translation saved successfully!",
                    "comm_dialog_title" to "Create New Language",
                    "comm_dialog_label" to "Name (e.g., Español)",
                    "comm_dialog_create" to "Create",
                    "comm_dialog_cancel" to "Cancel",
                    "friends_header" to "Add Pup Friend via GitHub",
                    "friends_name_label" to "Developer Name (Optional)",
                    "friends_link_label" to "GitHub link or username",
                    "friends_add_btn" to "Identify and Add Pup Friend",
                    "config_header" to "Settings & Storage",
                    "config_snack_alert" to "Treat Alerts",
                    "config_snack_desc" to "Remember to give snacks to Floquinho",
                    "config_storage_title" to "Storage Manager (Translations)",
                    "config_export_btn" to "Export",
                    "config_import_btn" to "Import",
                    "config_active_lang" to "Active App Language",
                    "affection_info" to "Affection"
                ),
                "한국어" to mutableStateMapOf(
                    "tab_inicio" to "홈",
                    "tab_comunidade" to "커뮤니티",
                    "tab_amizades" to "친구",
                    "tab_config" to "설정",
                    "hero_title" to "안녕, 나는 플로퀴뉴야!",
                    "hero_bio" to "캐러멜 & 크림색 포메라니안으로, 카메라를 보고 웃거나 간식을 조르는 전문가예요.",
                    "card_breed_title" to "털 및 체격",
                    "card_breed_desc" to "초롱초롱한 귀와 동네에서 가장 행복한 미소를 가진 몽글몽글한 털뭉치.",
                    "card_mood_title" to "현재 기분",
                    "card_mood_desc" to "100% 신남, 거실에서 놀거나 간식 먹을 준비 완료.",
                    "card_snack_title" to "가장 좋아하는 간식",
                    "card_snack_desc" to "바삭한 닭고기 비스킷과 한 입 크기의 사과 조각.",
                    "friends_status" to "개발자 멍멍이 친구들",
                    "comm_title" to "커뮤니티 번역",
                    "comm_editing" to "편집 중",
                    "comm_new_lang_btn" to "새 언어 만들기",
                    "comm_confirm_btn" to "언어 확인 및 적용",
                    "comm_success" to "번역이 성공적으로 저장되었습니다!",
                    "comm_dialog_title" to "새 언어 만들기",
                    "comm_dialog_label" to "이름 (예: 한국어, KOR)",
                    "comm_dialog_create" to "만들기",
                    "comm_dialog_cancel" to "취소",
                    "friends_header" to "GitHub를 통해 멍멍이 친구 추가",
                    "friends_name_label" to "개발자 이름 (선택사항)",
                    "friends_link_label" to "GitHub 링크 또는 사용자 이름",
                    "friends_add_btn" to "친구 확인 및 추가",
                    "config_header" to "설정 및 스토리지",
                    "config_snack_alert" to "간식 알림",
                    "config_snack_desc" to "플로퀴뉴에게 간식 주는 것 기억하기",
                    "config_storage_title" to "스토리지 관리자 (번역)",
                    "config_export_btn" to "내보내기",
                    "config_import_btn" to "가져오기",
                    "config_active_lang" to "앱 활성 언어",
                    "affection_info" to "애정"
                )
            )
        }
    }

    var activeLanguage by remember { mutableStateOf("Português (BR)") }
    var currentTab by remember { mutableStateOf(0) }
    var affectionData by remember { mutableStateOf(sharedPrefs.getInt("affection_data_count", 42)) }
    var modoTurboCarinho by remember { mutableStateOf(true) }

    val amigos = remember {
        val savedAmigos = sharedPrefs.getString("amigos_storage_json", null)
        if (savedAmigos != null) {
            try {
                val jsonArr = JSONArray(savedAmigos)
                val list = mutableStateListOf<AmigoDev>()
                for (i in 0 until jsonArr.length()) {
                    val obj = jsonArr.getJSONObject(i)
                    list.add(
                        AmigoDev(
                            nome = obj.getString("nome"),
                            githubUser = obj.getString("githubUser"),
                            avatarUrl = obj.getString("avatarUrl"),
                            favorito = obj.getBoolean("favorito")
                        )
                    )
                }
                list
            } catch (e: Exception) {
                mutableStateListOf(
                    AmigoDev("AndroidDev", "android", "https://github.com/android.png", true),
                    AmigoDev("Jetpack", "androidx", "https://github.com/androidx.png", false)
                )
            }
        } else {
            mutableStateListOf(
                AmigoDev("AndroidDev", "android", "https://github.com/android.png", true),
                AmigoDev("Jetpack", "androidx", "https://github.com/androidx.png", false)
            )
        }
    }

    fun salvarAmigosNoStorage() {
        val jsonArr = JSONArray()
        amigos.forEach { amg ->
            val obj = JSONObject()
            obj.put("nome", amg.nome)
            obj.put("githubUser", amg.githubUser)
            obj.put("avatarUrl", amg.avatarUrl)
            obj.put("favorito", amg.favorito)
            jsonArr.put(obj)
        }
        sharedPrefs.edit().putString("amigos_storage_json", jsonArr.toString()).apply()
    }

    fun salvarCarinhoNoStorage(novoValor: Int) {
        affectionData = novoValor
        sharedPrefs.edit().putInt("affection_data_count", novoValor).apply()
    }

    fun t(key: String): String = translations[activeLanguage]?.get(key) ?: translations["Português (BR)"]?.get(key) ?: key

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 4.dp
            ) {
                val items = listOf(
                    Triple(t("tab_inicio"), Icons.Rounded.Pets, 0),
                    Triple(t("tab_comunidade"), Icons.Rounded.Translate, 1),
                    Triple(t("tab_amizades"), Icons.Rounded.Favorite, 2),
                    Triple(t("tab_config"), Icons.Rounded.Settings, 3)
                )
                items.forEach { (label, icon, index) ->
                    NavigationBarItem(
                        selected = currentTab == index,
                        onClick = { currentTab = index },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label, maxLines = 1, fontSize = 11.sp) }
                    )
                }
            }
        }
    ) { innerPadding ->
        AnimatedContent(
            targetState = currentTab,
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            transitionSpec = {
                val direction = if (targetState > initialState) 1 else -1
                (slideInHorizontally(animationSpec = tween(320)) { width -> direction * width } + fadeIn(tween(320)))
                    .togetherWith(
                        slideOutHorizontally(animationSpec = tween(320)) { width -> -direction * width } + fadeOut(tween(220))
                    )
            },
            label = "TabSlideAnimation"
        ) { targetTab ->
            when (targetTab) {
                0 -> InicioTab(
                    t = ::t,
                    activeLanguage = activeLanguage,
                    affectionData = affectionData,
                    onDarCarinho = { salvarCarinhoNoStorage(affectionData + 1) }
                )
                1 -> ComunidadeTraducoesTab(
                    t = ::t,
                    translations = translations,
                    activeLanguage = activeLanguage,
                    onSelectLanguage = { activeLanguage = it },
                    onSaveTranslations = {
                        val json = JSONObject()
                        translations.forEach { (lang, map) ->
                            val subJson = JSONObject()
                            map.forEach { (k, v) -> subJson.put(k, v) }
                            json.put(lang, subJson)
                        }
                        sharedPrefs.edit().putString("traducoes_storage_json", json.toString()).apply()
                    }
                )
                2 -> AmizadesTab(
                    t = ::t,
                    amigos = amigos,
                    onToggleAmigo = { idx ->
                        val item = amigos[idx]
                        amigos[idx] = item.copy(favorito = !item.favorito)
                        salvarAmigosNoStorage()
                    },
                    onDeleteAmigo = { idx ->
                        amigos.removeAt(idx)
                        salvarAmigosNoStorage()
                    },
                    onAddAmigo = { nome, githubUser ->
                        val cleanUser = githubUser.trim().removePrefix("https://github.com/").removeSuffix("/")
                        val avatar = "https://github.com/$cleanUser.png"
                        amigos.add(AmigoDev(nome.ifBlank { cleanUser }, cleanUser, avatar, true))
                        salvarAmigosNoStorage()
                    }
                )
                3 -> ConfiguracoesTab(
                    t = ::t,
                    activeLanguage = activeLanguage,
                    availableLanguages = translations.keys.toList(),
                    onSelectLanguage = { activeLanguage = it },
                    modoTurboCarinho = modoTurboCarinho,
                    onToggleTurbo = { modoTurboCarinho = it },
                    sharedPreferences = sharedPrefs,
                    translations = translations,
                    amigos = amigos,
                    affectionData = affectionData
                )
            }
        }
    }
}

@Composable
fun InicioTab(
    t: (String) -> String,
    activeLanguage: String,
    affectionData: Int,
    onDarCarinho: () -> Unit
) {
    val bgColor = MaterialTheme.colorScheme.background
    val cardColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
    val dynamicTitleColor = MaterialTheme.colorScheme.primary
    val dynamicDescColor = MaterialTheme.colorScheme.onSurfaceVariant

    val langCodeClean = when {
        activeLanguage.equals("Português (BR)", ignoreCase = true) -> "pt"
        activeLanguage.equals("English", ignoreCase = true) -> "en"
        activeLanguage.equals("한국어", ignoreCase = true) -> "ko"
        activeLanguage.contains("(") -> activeLanguage.substringAfter("(").substringBefore(")")
        else -> activeLanguage.take(2).lowercase()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.floquinho_foto),
            contentDescription = "Foto do Floquinho",
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .border(3.dp, MaterialTheme.colorScheme.primary, CircleShape)
        )

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = t("hero_title"),
            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
            color = dynamicTitleColor
        )

        Text(
            text = t("hero_bio"),
            style = MaterialTheme.typography.bodyMedium,
            color = dynamicDescColor,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
        )

        AssistChip(
            onClick = onDarCarinho,
            label = { Text("${t("affection_info")}: $affectionData • $langCodeClean") },
            leadingIcon = { Icon(Icons.Rounded.Pets, contentDescription = null, modifier = Modifier.size(18.dp)) },
            shape = RoundedCornerShape(100.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = cardColor
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                GiantCardSection(title = t("card_breed_title"), description = t("card_breed_desc"), titleColor = dynamicTitleColor, descColor = dynamicDescColor)
                HorizontalDivider(thickness = 2.dp, color = bgColor)
                GiantCardSection(title = t("card_mood_title"), description = t("card_mood_desc"), titleColor = dynamicTitleColor, descColor = dynamicDescColor)
                HorizontalDivider(thickness = 2.dp, color = bgColor)
                GiantCardSection(title = t("card_snack_title"), description = t("card_snack_desc"), titleColor = dynamicTitleColor, descColor = dynamicDescColor)
            }
        }
    }
}

@Composable
fun GiantCardSection(title: String, description: String, titleColor: Color, descColor: Color) {
    Column(modifier = Modifier.fillMaxWidth().padding(20.dp)) {
        Text(text = title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = titleColor)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = description, style = MaterialTheme.typography.bodyMedium, color = descColor)
    }
}

@Composable
fun ComunidadeTraducoesTab(
    t: (String) -> String,
    translations: SnapshotStateMap<String, SnapshotStateMap<String, String>>,
    activeLanguage: String,
    onSelectLanguage: (String) -> Unit,
    onSaveTranslations: () -> Unit
) {
    var editingLang by remember { mutableStateOf(activeLanguage) }
    var showNewLangDialog by remember { mutableStateOf(false) }

    val draftFields = remember(editingLang) {
        mutableStateMapOf<String, String>().apply {
            TRANSLATION_KEYS.forEach { (key, _) ->
                put(key, translations[editingLang]?.get(key) ?: "")
            }
        }
    }

    val fieldErrors = remember(editingLang) { mutableStateMapOf<String, Boolean>() }
    var savedBanner by remember { mutableStateOf(false) }

    val langCodeClean = when {
        editingLang.equals("Português (BR)", ignoreCase = true) -> "pt"
        editingLang.equals("English", ignoreCase = true) -> "en"
        editingLang.equals("한국어", ignoreCase = true) -> "ko"
        editingLang.contains("(") -> editingLang.substringAfter("(").substringBefore(")")
        else -> editingLang.take(2).lowercase()
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = t("comm_title"),
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "${t("comm_editing")}: $langCodeClean",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            translations.keys.forEach { lang ->
                FilterChip(
                    selected = editingLang == lang,
                    onClick = {
                        editingLang = lang
                        savedBanner = false
                    },
                    shape = RoundedCornerShape(100.dp),
                    label = { 
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(lang)
                            if (lang != "Português (BR)" && lang != "English" && translations.size > 1) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Excluir",
                                    modifier = Modifier.size(16.dp).clickable {
                                        translations.remove(lang)
                                        if (editingLang == lang) editingLang = translations.keys.first()
                                        onSaveTranslations()
                                    },
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        TRANSLATION_KEYS.forEach { (key, humanLabel) ->
            val value = draftFields[key] ?: ""
            val isError = fieldErrors[key] == true

            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                OutlinedTextField(
                    value = value,
                    onValueChange = { newText ->
                        draftFields[key] = newText
                        if (newText.isNotBlank()) fieldErrors[key] = false
                        savedBanner = false
                    },
                    label = { Text("$humanLabel ($key)") },
                    isError = isError,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                var hasAnyEmpty = false
                TRANSLATION_KEYS.forEach { (key, _) ->
                    val empty = draftFields[key].isNullOrBlank()
                    fieldErrors[key] = empty
                    if (empty) hasAnyEmpty = true
                }
                if (!hasAnyEmpty) {
                    val targetMap = translations.getOrPut(editingLang) { mutableStateMapOf() }
                    TRANSLATION_KEYS.forEach { (key, _) -> targetMap[key] = draftFields[key]!!.trim() }
                    onSelectLanguage(editingLang)
                    onSaveTranslations()
                    savedBanner = true
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(100.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Translate, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(t("comm_confirm_btn"))
            }
        }

        if (savedBanner) {
            Spacer(modifier = Modifier.height(8.dp))
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "✨ ${t("comm_success")}",
                    color = MaterialTheme.colorScheme.onPrimaryContainer,
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = t("comm_new_lang_btn"),
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(10.dp))
                FilledTonalButton(
                    onClick = { showNewLangDialog = true },
                    modifier = Modifier.fillMaxWidth().height(50.dp),
                    shape = RoundedCornerShape(100.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Rounded.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                        Text(t("comm_new_lang_btn"))
                    }
                }
            }
        }
    }

    if (showNewLangDialog) {
        var newLangName by remember { mutableStateOf("") }
        var newLangError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showNewLangDialog = false },
            title = { Text(t("comm_dialog_title")) },
            text = {
                OutlinedTextField(
                    value = newLangName,
                    onValueChange = { newLangName = it; if (it.isNotBlank()) newLangError = false },
                    label = { Text(t("comm_dialog_label")) },
                    isError = newLangError,
                    shape = RoundedCornerShape(14.dp),
                    singleLine = true
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (newLangName.isBlank()) {
                            newLangError = true
                        } else {
                            val trimmed = newLangName.trim()
                            if (!translations.containsKey(trimmed)) {
                                translations[trimmed] = mutableStateMapOf()
                            }
                            editingLang = trimmed
                            showNewLangDialog = false
                            onSaveTranslations()
                        }
                    },
                    shape = RoundedCornerShape(100.dp)
                ) {
                    Text(t("comm_dialog_create"))
                }
            },
            dismissButton = {
                TextButton(onClick = { showNewLangDialog = false }) { Text(t("comm_dialog_cancel")) }
            }
        )
    }
}

@Composable
fun AmizadesTab(
    t: (String) -> String,
    amigos: List<AmigoDev>,
    onToggleAmigo: (Int) -> Unit,
    onDeleteAmigo: (Int) -> Unit,
    onAddAmigo: (String, String) -> Unit
) {
    var gitHubInput by remember { mutableStateOf("") }
    var nomePerfil by remember { mutableStateOf("") }
    var erroInput by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)
    ) {
        Text(
            text = t("friends_status"),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ) {
            Column {
                amigos.forEachIndexed { index, amigo ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            AsyncImage(
                                model = amigo.avatarUrl,
                                contentDescription = "Avatar GitHub",
                                modifier = Modifier.size(48.dp).clip(CircleShape).border(1.5.dp, MaterialTheme.colorScheme.primary, CircleShape),
                                contentScale = ContentScale.Crop
                            )
                            Column {
                                Text(text = amigo.nome, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                                Text(text = "github.com/${amigo.githubUser}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { onToggleAmigo(index) }) {
                                Icon(
                                    imageVector = if (amigo.favorito) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                                    contentDescription = "Favoritar",
                                    tint = if (amigo.favorito) Color(0xFFD32F2F) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(onClick = { onDeleteAmigo(index) }) {
                                Icon(
                                    imageVector = Icons.Rounded.Delete,
                                    contentDescription = "Excluir Amigo",
                                    tint = MaterialTheme.colorScheme.error
                                )
                            }
                        }
                    }
                    if (index < amigos.lastIndex) HorizontalDivider(thickness = 2.dp, color = MaterialTheme.colorScheme.background)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = t("friends_header"),
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = nomePerfil,
            onValueChange = { nomePerfil = it },
            label = { Text(t("friends_name_label")) },
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(8.dp))

        OutlinedTextField(
            value = gitHubInput,
            onValueChange = { gitHubInput = it; if (it.isNotBlank()) erroInput = false },
            label = { Text(t("friends_link_label")) },
            isError = erroInput,
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.fillMaxWidth()
        )
        if (erroInput) {
            Text("Insira um link ou usuário válido do GitHub.", color = Color(0xFFD32F2F), style = MaterialTheme.typography.labelMedium)
        }

        Spacer(modifier = Modifier.height(12.dp))

        Button(
            onClick = {
                if (gitHubInput.isBlank()) {
                    erroInput = true
                } else {
                    onAddAmigo(nomePerfil, gitHubInput)
                    nomePerfil = ""
                    gitHubInput = ""
                }
            },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(100.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Code, contentDescription = null, modifier = Modifier.size(18.dp))
                Text(t("friends_add_btn"))
            }
        }
    }
}

@Composable
fun ConfiguracoesTab(
    t: (String) -> String,
    activeLanguage: String,
    availableLanguages: List<String>,
    onSelectLanguage: (String) -> Unit,
    modoTurboCarinho: Boolean,
    onToggleTurbo: (Boolean) -> Unit,
    sharedPreferences: android.content.SharedPreferences,
    translations: SnapshotStateMap<String, SnapshotStateMap<String, String>>,
    amigos: List<AmigoDev>,
    affectionData: Int
) {
    var statusExportacao by remember { mutableStateOf("") }
    val context = LocalContext.current
    val bgColor = MaterialTheme.colorScheme.background

    val exportLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    val sb = StringBuilder()
                    sb.append("createNewLang=false\n")
                    sb.append("langModification=${activeLanguage.take(2).lowercase()}\n")
                    sb.append("langName=$activeLanguage\n")
                    sb.append("affectionData=$affectionData\n")
                    
                    translations[activeLanguage]?.forEach { (k, v) ->
                        sb.append("$k=$v\n")
                    }

                    context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                        outputStream.write(sb.toString().toByteArray())
                    }
                    statusExportacao = "Arquivo .flang exportado com sucesso!"
                } catch (e: Exception) {
                    statusExportacao = "Erro ao exportar: ${e.localizedMessage}"
                }
            }
        }
    }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            result.data?.data?.let { uri ->
                try {
                    val fileContent = context.contentResolver.openInputStream(uri)?.bufferedReader().use { it?.readText() }
                    if (fileContent != null) {
                        val lines = fileContent.split("\n")
                        var isNewLang = false
                        var langCode = "custom_lang"
                        var customLangName = ""
                        val newMap = mutableStateMapOf<String, String>()

                        lines.forEach { line ->
                            val trimmed = line.trim()
                            if (trimmed.isNotEmpty() && !trimmed.startsWith("#")) {
                                val parts = trimmed.split("=", limit = 2)
                                if (parts.size == 2) {
                                    val key = parts[0].trim()
                                    val value = parts[1].trim()
                                    when (key) {
                                        "createNewLang" -> isNewLang = (value.lowercase() == "true")
                                        "langModification" -> langCode = value
                                        "langName" -> customLangName = value
                                        "affectionData" -> {}
                                        else -> newMap[key] = value
                                    }
                                }
                            }
                        }

                        val finalLangName = if (customLangName.isNotBlank()) customLangName else (if (isNewLang) "Idioma ($langCode)" else langCode)
                        translations[finalLangName] = newMap
                        onSelectLanguage(finalLangName)

                        val rootJson = JSONObject()
                        translations.forEach { (l, m) ->
                            val subJson = JSONObject()
                            m.forEach { (k, v) -> subJson.put(k, v) }
                            rootJson.put(l, subJson)
                        }
                        sharedPreferences.edit().putString("traducoes_storage_json", rootJson.toString()).apply()

                        statusExportacao = "Arquivo .flang importado com sucesso!"
                    }
                } catch (e: Exception) {
                    statusExportacao = "Erro ao importar: ${e.localizedMessage}"
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text(
            text = t("config_header"),
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.primary
        )

        Spacer(modifier = Modifier.height(12.dp))

        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                // Seção 1: Alertas de Petisco
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = t("config_snack_alert"), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                            Text(text = t("config_snack_desc"), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = modoTurboCarinho, onCheckedChange = onToggleTurbo)
                    }
                }

                HorizontalDivider(thickness = 2.dp, color = bgColor)

                // Seção 2: Gerenciador de Storage (.flang)
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(text = t("config_storage_title"), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = {
                                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TITLE, "floquinho_traducao.flang")
                                }
                                exportLauncher.launch(intent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(100.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Rounded.Upload, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(t("config_export_btn"))
                            }
                        }

                        FilledTonalButton(
                            onClick = {
                                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                                    addCategory(Intent.CATEGORY_OPENABLE)
                                    type = "*/*"
                                }
                                importLauncher.launch(intent)
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(100.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Rounded.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                                Text(t("config_import_btn"))
                            }
                        }
                    }

                    if (statusExportacao.isNotBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = statusExportacao, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                    }
                }

                HorizontalDivider(thickness = 2.dp, color = bgColor)

                // Seção 3: Idioma Ativo no App
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(text = t("config_active_lang"), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.height(8.dp))
                    availableLanguages.forEach { lang ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectLanguage(lang) }
                                .padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(selected = activeLanguage == lang, onClick = { onSelectLanguage(lang) })
                            Spacer(Modifier.width(8.dp))
                            Text(lang, color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }
    }
}